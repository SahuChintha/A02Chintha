
$(document).ready(function(){
    $("#submit").click(allert) ;
})

function result(i,j,k)
{
    return i*j*k ;
}

function allert() {
    var first = document.getElementById("fname").value;
    var second = $("#lname").val();
    var pls = $("#place").val();
    var pnum = $("#num").val();
    var truth;
    var radioValue = $("input[name='sel']:checked").val();
            if(radioValue){
            truth = radioValue ;
            }
    
    var des;
    if(pls=="japan")
        var des = 6303;
    else if(pls=="india")
        var des = 8431;
     else if(pls=="france")
        var des = 4760;
    else if(pls=="italy")
        var des = 5352;
    else if(pls=="austrilya")
        var des = 9429;
    else if(pls=="london")
        var des = 4884;
    
     var t;
    
    if(radioValue=="oneway")
        var t=1;
        else if(radioValue=="to and fro")
        var t=2;
            
      alert("Hi "+first+" "+second+"\nyou have decided to go to "+pls+"\nnumber of people: "+pnum+"\ntravel type:"+truth);      
     alert("your total cost of travell will be: $ "+result(des,0.11,t)) ;      
    alert("thankyou");
     var f=result(des,0.11,t);
  go.innerHTML=f;

}
