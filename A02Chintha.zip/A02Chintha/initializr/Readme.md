This is a project done by me Sahu Chintha a Northwest missouri student as part of my assignment.
I have used Bootstrap, html, css and jquery in this project.my partner for this project were Swaroop Gembali and Joel Beckley .

 Homepage: 
   -profile picture
   -video 
   -a breaf discription about me
 your choice:
   -a small form that calculates travel charges for different countries
 contact:
   -a contact form and my emailID.
 about me:
   -lot of information about me.
test:
